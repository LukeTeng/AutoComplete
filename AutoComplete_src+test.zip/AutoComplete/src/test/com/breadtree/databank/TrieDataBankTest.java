package com.breadtree.databank;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TrieDataBankTest {

	static Logger logger = Logger.getLogger(DataBank.class.getName());

	private static TrieDataBank trie = null;

	@Before
	public void setUp() throws Exception {

		trie = new TrieDataBank();
		dataPreparation();

		// log4j configuration
		PropertyConfigurator.configure(System.getProperty("user.dir")
				+ "/log4j.properties");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCountPrefixes() {

		assertEquals(7, trie.countPrefixes("a"));
		assertEquals(6, trie.countPrefixes("ab"));
		assertEquals(6, trie.countPrefixes("AB"));
		assertEquals(4, trie.countPrefixes("t"));
		assertEquals(4, trie.countPrefixes("v"));

		assertEquals(0, trie.countPrefixes("g"));
		assertEquals(0, trie.countPrefixes("aggggggggggggggg"));
		assertEquals(1, trie.countPrefixes("abcedfdddtttttttttttdddddttttttt"));
		assertEquals(0, trie.countPrefixes("abcedfdddtttttttttttdddddtttttttd"));

		// special character, no match
		assertEquals(0, trie.countPrefixes("@@@@$$$"));
		// space inside, no match
		assertEquals(0, trie.countPrefixes("take a test"));
	}

	@Test
	public void testCountWords() {

		assertEquals(1, trie.countWords("a"));
		assertEquals(1, trie.countWords("ab"));
		assertEquals(1, trie.countWords("AB"));
		assertEquals(0, trie.countWords("t"));
		assertEquals(0, trie.countWords("v"));

		assertEquals(0, trie.countWords("g"));
		assertEquals(0, trie.countWords("aggggggggggggggg"));
		assertEquals(1, trie.countWords("abcedfdddtttttttttttdddddtttttttt"));
		assertEquals(0, trie.countWords("abcedfdddtttttttttttdddddtttttttd"));

		// special character, no match
		assertEquals(0, trie.countWords("@@@@$$$"));
		// space inside, no match
		assertEquals(0, trie.countWords("take a test"));

	}

	@Test
	public void testCountTotalWordsUnderNode() {
		assertEquals(17, trie.countTotalWordsUnderNode(trie.getVertx(trie)));
	}

	// @Test
	// public void testAddWord() {
	// fail("Not yet implemented");
	// }

	@Test
	public void testLoadData() {

		ArrayList<String> arrayList = new ArrayList<String>();

		arrayList.add("abcedfddddddd");
		arrayList.add("a");
		arrayList.add("ba");
		arrayList.add("abce");
		arrayList.add("ab");
		arrayList.add("ABCD");
		arrayList.add("abcedfdddd");
		arrayList.add("ttttttttttttttttttttttt");
		arrayList.add("abcef");
		arrayList.add("testtest");
		arrayList.add("testtest");
		arrayList.add("testtest");
		arrayList.add("vtesttest");
		arrayList.add("vtesttest");
		arrayList.add("vtesttestkkkkkkk");
		arrayList.add("vtesttestkkjktetet");
		arrayList.add("abcedfdddtttttttttttdddddtttttttt");

		// special character, can not be added successfully
		arrayList.add("@@@%@%%%%@%%%");
		arrayList.add("ggg ggg ggg");

		trie.loadData(arrayList);

		assertEquals(17, trie.countTotalWordsUnderNode(trie.getVertx(trie)));

	}

	private void dataPreparation() {

		trie.addWord("abcedfddddddd");
		trie.addWord("a");
		trie.addWord("ba");
		trie.addWord("abce");
		trie.addWord("ab");
		trie.addWord("ABCD");
		trie.addWord("abcedfdddd");
		trie.addWord("ttttttttttttttttttttttt");
		trie.addWord("abcef");
		trie.addWord("testtest");
		trie.addWord("testtest");
		trie.addWord("testtest");
		trie.addWord("vtesttest");
		trie.addWord("vtesttest");
		trie.addWord("vtesttestkkkkkkk");
		trie.addWord("vtesttestkkjktetet");
		trie.addWord("abcedfdddtttttttttttdddddtttttttt");

		// The following items can not be added successfully
		trie.addWord("@@@%@%%%%@%%%");
		trie.addWord("ggg ggg ggg");
		trie.addWord("");

		// System.out.println(trie.countPrefixes("a"));
		// System.out.println(trie.countPrefixes("t"));
		// System.out.println(trie.countPrefixes("v"));

	}
}
