package com.breadtree.databank;

import static org.junit.Assert.assertEquals;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.Before;
import org.junit.Test;

import com.breadtree.handler.FileHandler;
import com.breadtree.handlerfactory.SimpleHandlerFactory;

public class FileHandlerTest {
	
	static Logger logger = Logger.getLogger(FileHandlerTest.class.getName());
	
	static String FILE_PATH_HOME;
	private String correctPath = null;
	private String incorrectPath = null;
	
	SimpleHandlerFactory simpleFactory;
	FileHandler fileHandler;
	DataBank myDataBank;
	
	@Before
	public void setUp() throws Exception {
		
		FILE_PATH_HOME = System.getProperty("user.dir");
		correctPath = FILE_PATH_HOME + "/testword.txt";
		incorrectPath = FILE_PATH_HOME + "/src/test.txt";
		
		//create a FileHandler instance to synchronize data from File source
        PropertyConfigurator.configure(FILE_PATH_HOME + "/log4j.properties");
		
        //create an instance of simple factory
		simpleFactory = new SimpleHandlerFactory();

		fileHandler = new FileHandler();
		
		//create a Databank instance to store data and match data
		myDataBank = simpleFactory.getDataBank("ArrayList");
		
		//DataBank is part of Handler, transfer myDataBank's reference to myHandler
		fileHandler.setDataBank(myDataBank);
	}



	/*
	 * read file unsuccessfully
	 */
	@Test
	public void fileHandlerTest1() {

		int result = 1;

		try {
			// incorrect file name
			result = fileHandler.readTxtFile(incorrectPath);
			assertEquals(-1, result);

			// file name is set as null
			result = fileHandler.readTxtFile(null);
			assertEquals(-1, result);

			// file name is set as empty
			result = fileHandler.readTxtFile("");
			assertEquals(-1, result);

			// file name is set as some special characters
			result = fileHandler.readTxtFile("$%$$##$$#$");
			assertEquals(-1, result);

			// file name is set as some special characters
			result = fileHandler.readTxtFile("%%%%%ssaittjiji///???");
			assertEquals(-1, result);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 * read file successfully
	 */
	@Test
	public void fileHandlerTest2() {

		int result = -1;

		try {
			// success case
			result = fileHandler.readTxtFile(correctPath);
			assertEquals(1, result);

			// read the same file at second time, it will return 0.
			// at this condition, no need to read the file again.
			result = fileHandler.readTxtFile(correctPath);
			assertEquals(0, result);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	/*
	 * match data successfully
	 */
	@Test
	public void matchDataTest1() {

		try {
			
			fileHandler.syncData();
			Thread.sleep(2 * 1000);
			
			myDataBank.matchData("he");
			assertEquals(true, myDataBank.getMatchResult());

			myDataBank.matchData("le");
			assertEquals(true, myDataBank.getMatchResult());

			myDataBank.matchData("letttttttttttttttttttttttttttttttttttttttttt");
			assertEquals(true, myDataBank.getMatchResult());

			myDataBank.matchData("@@$$%%");
			assertEquals(true, myDataBank.getMatchResult());

			myDataBank.matchData("%%%%---***$$##!!@@");
			assertEquals(true, myDataBank.getMatchResult());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * match data failed due to input error
	 */
	@Test
	public void matchDataTest2() {

		try {
			fileHandler.readTxtFile(correctPath);

			myDataBank.matchData("");
			assertEquals(false, myDataBank.getMatchResult());

			myDataBank.matchData(null);
			assertEquals(false, myDataBank.getMatchResult());
			
			myDataBank.matchData("he");
			assertEquals(true, myDataBank.getMatchResult());

			myDataBank.matchData("@@@@@@@@@@@@");
			assertEquals(true, myDataBank.getMatchResult());
			
			// input is too long
			myDataBank.matchData("lettttttttttttttttttttttTTTTTTTTTTTTTTTTTTTTTTTT"
					+ "TTTTTTTTTTTTTTTTTttttttttttttttttttttttttttttttttttttttttt"
					+ "tttttttttttttttttttttttttttttttttttttttttttttttttttttttttt");
			assertEquals(false, myDataBank.getMatchResult());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * operate task successfully
	 */
	@Test
	public void myTaskTest1() {

		try {
			//check if the loop counter is correct.
			fileHandler.syncData();
			Thread.sleep(10 * 1000);
			int temp = fileHandler.getLoopCounter();
			assert (temp > 1 && temp < 4);
			
			Thread.sleep(10 * 1000);
			temp = fileHandler.getLoopCounter();
			assert (temp > 3 && temp < 6);

			Thread.sleep(10 * 1000);
			temp = fileHandler.getLoopCounter();
			assert (temp > 5 && temp < 8);
			
			// stop the timer task
			fileHandler.setTaskStopSignal(true);
			
			Thread.sleep(10 * 1000);
			assert (fileHandler.getLoopCounter() == 0);
						
			Thread.sleep(10 * 1000);
			assert (fileHandler.getLoopCounter() == 0);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
