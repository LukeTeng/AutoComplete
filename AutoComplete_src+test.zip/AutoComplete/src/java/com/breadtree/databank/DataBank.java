package com.breadtree.databank;

import java.util.ArrayList;


public interface DataBank {
	
	//The maximum length of input prefix
	public static final int MAX_LENGTH_OF_PREFIX = 50;
	/*
	 * this method is used to load data from input array list into its own data structure, ArrayList, Tree, HashMap, or others.
	 * it will be overrode to provide different data structure for the purpose of matching efficiency. 
	 */
	public int loadData(ArrayList<String> wordList);

	/*
	 * this method is used to match records with the input parameter as prefix.
	 * it will be overrode to match data efficiently. 
	 */
	public ArrayList<String> matchData(String prefix);
	
    /*
     * this method is used to identify whether or not the matchedData method executed successfully.
     * true: success; false: fail.
     */
	public boolean getMatchResult();
	public void setMatchResult(boolean result);
}