package com.breadtree.databank;


import java.util.List;


public interface DataBank {
	
	//The maximum length of input prefix
	public static final int MAX_LENGTH_OF_PREFIX = 50;
	
	/*
	 * this method is used to load data from input array list into its own data structure
	 */
	public int loadData(List<String> wordList);
	
	/*
	 * this method is used to match records with the input parameter as prefix.
	 */
	public List<String> matchData(String prefix);
}