package com.breadtree.databank;

import java.util.ArrayList;

public class HashMapDataBank implements DataBank {
	
	private boolean returnResult = false;
	
	@Override
	public int loadData(ArrayList<String> wordlist) {

		// To be implemented
		return -1;

	}

	@Override
	public ArrayList<String> matchData(String prefix) {

		// To be implemented
		return null;
	}
	
	
	@Override
	public boolean getMatchResult(){
		return returnResult;
	}
	
	
	@Override
	public void setMatchResult(boolean result){
		this.returnResult = result;
	}

}
