package com.breadtree.databank;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.apache.log4j.Logger;

public class TrieDataBank implements DataBank {

	static Logger logger = Logger.getLogger(DataBank.class.getName());

	private Vertex root = new Vertex();

	// for the purpose of synchronization
	private String strObject = new String();

	protected class Vertex {
		// number of word
		protected int words;
		// number of prefix
		protected int prefixes;
		// number of sub-node
		protected Vertex[] edges;

		// to support English character only, case non-sensitive
		Vertex() {
			this.words = 0;
			this.prefixes = 0;
			edges = new Vertex[26];
			for (int i = 0; i < edges.length; i++) {
				edges[i] = null;
			}
		}
	}

	/**
	 * get the number of words under specific node
	 */
	public int countTotalWordsUnderNode(Vertex vertex) {

		return vertex.prefixes + vertex.words;

	}

	/**
	 * get all the words under the specific node
	 */
	private void listAllWordsUnderNode(List<String> words, Vertex vertex,
			String prefix) {
		if (vertex.words != 0) {
			words.add(prefix);
		}
		Vertex[] edges = vertex.edges;
		for (int i = 0; i < edges.length; i++) {
			if (edges[i] != null) {
				String newPrefix = prefix + (char) ('a' + i);
				listAllWordsUnderNode(words, edges[i], newPrefix);
			}
		}
	}

	/**
	 * get the number words with the specific prefix
	 */
	public int countPrefixes(String prefix) {

		// check if it contains character only
		if (!prefix.matches("[a-zA-Z]+")) {
			return 0;
		}

		// change into lower case, non-case sensitive
		prefix = prefix.toLowerCase();

		return countPrefixes(root, prefix);
	}

	public int countPrefixes(Vertex vertex, String prefixSegment) {

		// reach the last character of the word
		if (prefixSegment.length() == 0) {
			return vertex.prefixes;
		}

		char c = prefixSegment.charAt(0);
		int index = c - 'a';
		if (vertex.edges[index] == null) {
			// the word does not exist
			return 0;
		} else {

			return countPrefixes(vertex.edges[index],
					prefixSegment.substring(1));

		}

	}

	/**
	 * get the number of matched words
	 */
	public int countWords(String word) {

		// check if it contains character only
		if (!word.matches("[a-zA-Z]+")) {
			return 0;
		}

		// change into lower case, non-case sensitive
		word = word.toLowerCase();

		return countWords(root, word);
	}

	private int countWords(Vertex vertex, String wordSegment) {

		// reach the last character of the word
		if (wordSegment.length() == 0) {
			return vertex.words;
		}

		char c = wordSegment.charAt(0);
		int index = c - 'a';
		if (vertex.edges[index] == null) { // the word does not exist
			return 0;
		} else {
			return countWords(vertex.edges[index], wordSegment.substring(1));
		}

	}

	/**
	 * add a word into trie
	 */
	public void addWord(String word) {

		if (!word.matches("[a-zA-Z]+")) {
			return;
		}
		// case non-sensitive
		word = word.toLowerCase();

		addWord(root, word);
	}

	private void addWord(Vertex vertex, String word) {

		// if all characters of the word has been added
		if (word.length() == 0) {
			vertex.words++;
		} else {
			vertex.prefixes++;
			char c = word.charAt(0);
			int index = c - 'a';
			// if the node does not exist
			if (vertex.edges[index] == null) {
				vertex.edges[index] = new Vertex();
			}
			// add the next character
			addWord(vertex.edges[index], word.substring(1));
		}
	}

	@Override
	public int loadData(List<String> wordlist) {

		if (wordlist == null || root == null || wordlist.size() < 0) {
			logger.fatal("internal error.");
			return -1;
		}

		// remove all the words contains non-character
		logger.debug(wordlist);
		ListIterator<String> listIterator = wordlist.listIterator();
		while (listIterator.hasNext()) {
			if (!(listIterator.next().matches("[a-zA-Z]+"))) {
				listIterator.remove();
			}
		}
		logger.debug(wordlist);

		// begin to load clear data element
		try {
			// clear all the existing element of
			// this data should be backuped first in case there is something
			// wrong

			synchronized (strObject) {

				root = new Vertex();

				for (int i = 0; i < wordlist.size(); i++) {
					logger.debug("adding word: " + wordlist.get(i));
					addWord(wordlist.get(i));
				}
			}
		} catch (Exception ex) {

			ex.printStackTrace();
			return -1;
		}

		return 1;

	}

	/*
	 * match records with the input parameter as prefix.
	 */
	public ArrayList<String> matchData(String prefix) {

		prefix = prefix.trim();

		if (!prefix.matches("[a-zA-Z]+")) {
			System.out
					.println("No special charactor or space is allowed, please input again.");
			return null;
		}
		if (prefix.length() > DataBank.MAX_LENGTH_OF_PREFIX) {
			System.out.println("Input is too long, please input again.");
			return null;
		}

		prefix = prefix.toLowerCase();

		ArrayList<String> words = new ArrayList<String>();

		synchronized (strObject) {

			// find the matched node firstly
			Vertex vertex = findVertex(root, prefix);
			if (vertex == null) {
				return null;
			}

			// list out all the words under this node
			listAllWordsUnderNode(words, vertex, prefix);
		}
		return words;
	}

	private Vertex findVertex(Vertex vertex, String prefix) {

		// reach the last character of the word
		if (prefix.length() == 0) {
			return vertex;
		}

		char c = prefix.charAt(0);
		int index = c - 'a';
		if (vertex.edges[index] == null) { // the word does NOT exist
			return null;
		} else {

			return findVertex(vertex.edges[index], prefix.substring(1));

		}
	}

	public Vertex getVertx(TrieDataBank trie) {
		return this.root;
	}

	public static void main(String args[]) {
		TrieDataBank trie = new TrieDataBank();

		trie.addWord("a");
		trie.addWord("ab");
		trie.addWord("abc");
		trie.addWord("z");
		trie.addWord("za");
		trie.addWord("zb");
		trie.addWord("zb");

		int totalWords = trie.countTotalWordsUnderNode(trie.root);
		System.out.println("Total number of words is: " + totalWords);

		List<String> allWords = new ArrayList<String>();
		trie.listAllWordsUnderNode(allWords, trie.root, "");

		System.out.println(allWords);

		int wordCounts = trie.countWords("vtesttest");
		System.out.println("WordCounts for vtesttest: " + wordCounts);

		int prefixCounts = trie.countPrefixes("vtesttest");
		System.out.println("Prefixcounts for vtesttest: " + prefixCounts);

		List<String> arrayStr = trie.matchData("abcedfddd");
		System.out.println(arrayStr);
	}

}
