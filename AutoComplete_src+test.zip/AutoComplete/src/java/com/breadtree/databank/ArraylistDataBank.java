package com.breadtree.databank;

import java.util.ArrayList;

import org.apache.log4j.Logger;


public class ArraylistDataBank implements DataBank {

	static Logger logger = Logger.getLogger(DataBank.class.getName());

	// synchronization flag to control the data integrity.
	private String strObject = new String();

	// DataBank's own container
	ArrayList<String> arraylistDatabank;
	ArrayList<String> matchedList;

	private boolean returnResult = false;
	
	public ArraylistDataBank() {
		arraylistDatabank = new ArrayList<String>();
		matchedList = new ArrayList<String>();
	}

	@Override
	public int loadData(ArrayList<String> wordlist) {

		if (wordlist == null || arraylistDatabank == null
				|| wordlist.size() < 0) {
			logger.fatal("internal error.");
			return -1;
		}

		try {
			// clear all the existing element of
			// this data should be backuped first in case there is something wrong
			arraylistDatabank.clear();

			synchronized (strObject) {

				for(int i=0; i<wordlist.size(); i++){
					arraylistDatabank.add(wordlist.get(i));
				}
			}
		} catch (Exception e) {

			return -1;
		}
		
        logger.debug(arraylistDatabank);
		return arraylistDatabank.size();

	}



	@Override
	public ArrayList<String> matchData(String prefix) {

		String temp = "";
		
		//set the match result as failed first
		setMatchResult(false);

		// check input
		if (prefix == null || prefix.trim().equals("")) {
			logger.warn("input is incorrect, please check again.");
			return null;
		}
		// check input length
		if (prefix.length() > MAX_LENGTH_OF_PREFIX) {
			logger.warn("input prefix is too long.");
			return null;
		}

		// check internal structure
		if (matchedList == null || arraylistDatabank == null) {
			logger.fatal("internal error.");
			return null;
		}

		try {
			// clear the matched list
			matchedList.clear();

			synchronized (strObject) {
				for (int i = 0; i < arraylistDatabank.size(); i++) {
					temp = arraylistDatabank.get(i);
					if (temp.startsWith(prefix)) {
						matchedList.add(temp);
					}
				}
			}
		} catch (Exception ex) {
			logger.error(ex);
			return null;
		}

		setMatchResult(true);
		return matchedList;
	}
	

	@Override
	public boolean getMatchResult(){
		return returnResult;
	}
	
	@Override
	public void setMatchResult(boolean result){
		this.returnResult = result;
	}

}
