package com.breadtree.util;

public enum DataBankType {

	// type list of DataBank
	ARRAYLIST, TRIE, HASHMAP
}
