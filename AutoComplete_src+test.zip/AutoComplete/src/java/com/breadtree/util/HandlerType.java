package com.breadtree.util;

public enum HandlerType {

	// type list of Handler
	FILE, DATABASE, HTTP

}
