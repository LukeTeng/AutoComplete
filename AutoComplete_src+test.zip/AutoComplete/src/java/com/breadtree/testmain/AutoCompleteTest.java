package com.breadtree.testmain;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.breadtree.databank.DataBank;
import com.breadtree.handler.Handler;
import com.breadtree.handlerfactory.SimpleHandlerFactory;
import com.breadtree.util.DataBankType;
import com.breadtree.util.HandlerType;

public class AutoCompleteTest {

	static Logger logger = Logger.getLogger(DataBank.class.getName());

	public static void main(String[] args) {

		// log4j configuration
		PropertyConfigurator.configure(System.getProperty("user.dir")
				+ "/log4j.properties");

		// create an instance of simple factory
		SimpleHandlerFactory simpleFactory = new SimpleHandlerFactory();
		try {
			// create a FileHandler instance to synchronize data from File
			// source
			Handler myHandler = simpleFactory.getHandler(HandlerType.FILE);

			// create a Databank instance to store data and match data
			DataBank myDataBank = simpleFactory.getDataBank(DataBankType.TRIE);

			// transfer myDataBank's reference to myHandler
			myHandler.setDataBank(myDataBank);

			// trigger a timer task to read file regularly
			// put data into DataBank through API loadData of DataBank
			myHandler.syncData();

			// interaction through console
			while (true) {
				BufferedReader br = new BufferedReader(new InputStreamReader(
						System.in));

				System.out.println("Please input prefix (max length:50):");
				String prefix = "";
				try {
					prefix = br.readLine();
				} catch (IOException e) {
					logger.equals(e);
				}

				if (prefix.trim() == null) {
					System.out
							.println("Sorry, your input is incorrect, please input again.");
				} else {
					List<String> ret = myHandler.getDataBank()
							.matchData(prefix);
					System.out.println(ret);
					logger.debug(ret);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}