package com.breadtree.handlerfactory;

import org.apache.log4j.Logger;
import com.breadtree.databank.DataBank;
import com.breadtree.databank.TrieDataBank;
import com.breadtree.handler.FileHandler;
import com.breadtree.handler.Handler;
import com.breadtree.util.DataBankType;
import com.breadtree.util.HandlerType;

public class SimpleHandlerFactory {

	static Logger logger = Logger.getLogger(SimpleHandlerFactory.class
			.getName());

	public Handler getHandler(HandlerType type) {

		switch (type) {
		case FILE:
			return new FileHandler();
			// break;
			// case DATABASE:
			// return new DatabaseHandler();
			// // break;
			// case HTTP:
			// return new HttpHandler();
			// break;
		default:
			return null;
		}

	}

	public DataBank getDataBank(DataBankType type) {

		switch (type) {
		// case ARRAYLIST:
		// return new ArraylistDataBank();
		// // break;
		case TRIE:
			return new TrieDataBank();
			// break;
			// case HASHMAP:
			// return new HashMapDataBank();
			// break;
		default:
			return null;
		}

	}
}
