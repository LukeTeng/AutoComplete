package com.breadtree.handlerfactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.breadtree.databank.ArraylistDataBank;
import com.breadtree.databank.DataBank;
import com.breadtree.databank.HashMapDataBank;
import com.breadtree.databank.TreeDataBank;
import com.breadtree.handler.DatabaseHandler;
import com.breadtree.handler.FileHandler;
import com.breadtree.handler.Handler;
import com.breadtree.handler.HttpHandler;


public class SimpleHandlerFactory {
	
	static Logger logger = Logger.getLogger(SimpleHandlerFactory.class.getName());
	
	public Handler getHandler(String handlerType) {
		if (handlerType.equals("FILE")) {
			return new FileHandler();
		} else if (handlerType.equals("DATABASE")) {
			return new DatabaseHandler();
		} else if (handlerType.equals("HTTP")) {
			return new HttpHandler();
		} else
		{
			logger.error("Handler type is wrong.");
			return null;
		}
	}

	public DataBank getDataBank(String dataBankType){
		if (dataBankType.equals("ArrayList")) {
			return new ArraylistDataBank();
		} else if (dataBankType.equals("HashMap")) {
			return new HashMapDataBank();
		} else if (dataBankType.equals("Tree")) {
			return new TreeDataBank();
		} else{
			logger.error("DataBank type is wrong.");
			return null;
		}
	}

	
	
	public static void main(String[] args) {
		
        //log4j configuration 
        PropertyConfigurator.configure(System.getProperty("user.dir") + "/log4j.properties");
		
        //create an instance of simple factory
		SimpleHandlerFactory simpleFactory = new SimpleHandlerFactory();
		try {
			//create a FileHandler instance to synchronize data from File source
			Handler myHandler = simpleFactory.getHandler("FILE");
			
			//create a Databank instance to store data and match data
			DataBank myDataBank = simpleFactory.getDataBank("ArrayList");
			
			//transfer myDataBank's reference to myHandler
			myHandler.setDataBank(myDataBank);
			
			//trigger a timer task to read file regularly 
			//put data into DataBank through API loadData of DataBank
			myHandler.syncData();
			
			//interaction through console
			while (true) {
				BufferedReader br = new BufferedReader(new InputStreamReader(
						System.in));

				System.out.println("Please input prefix (max length:50):");
				String prefix = "";
				try {
					prefix = br.readLine();
				} catch (IOException e) {
					logger.equals(e);
				}

				if (prefix.trim() == null) {
					System.out.println("Sorry, your input is incorrect, please input again.");
				} else {
					ArrayList<String> ret = myHandler.getDataBank().matchData(prefix);
					System.out.println(ret);
					logger.debug(ret);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
}
