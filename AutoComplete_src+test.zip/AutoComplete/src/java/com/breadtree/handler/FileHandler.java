package com.breadtree.handler;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Timer;

import org.apache.log4j.Logger;

import com.breadtree.databank.DataBank;


public class FileHandler implements Handler {

	static Logger logger = Logger.getLogger(FileHandler.class.getName());

	public static final int MAX_SIZE_OF_FILE = 1024 * 10;
	public static final int UPDATE_INTERVAL = 5000;

	public String FILE_PATH;

	private long lastUpdateFileSize = 0;
	private long lastUpdateFileModified = 0;

	private java.util.TimerTask myTask = null;
	private ArrayList<String> wordlist = new ArrayList<String>();

	// true: timerTask should be stopped.
	private boolean taskStopSignal = false;

	boolean matchResult = false;
	private int loopCounter = 0;

	DataBank dataBank;
	
	public int getLoopCounter() {
		return loopCounter;
	}

	public void setLoopCounter(int loopTime) {
		this.loopCounter = loopTime;
	}

	@Override
	public DataBank getDataBank() {
		return dataBank;
	}
	
	@Override
	public void setDataBank(DataBank dataBank) {
		this.dataBank = dataBank;
	}

	public boolean getTaskStopSignal() {
		return taskStopSignal;
	}

	public void setTaskStopSignal(boolean taskStopSignal) {
		this.taskStopSignal = taskStopSignal;
	}

	@Override
	public void syncData() {

		initEnv();

		// start the task to synchronize word list from file
		loopCounter = 0;
		Timer timer = new Timer();
		myTask = new MyTask();
		timer.schedule(myTask, 0, UPDATE_INTERVAL);
	}

	public void initEnv() {
		String relativelyPath = System.getProperty("user.dir");
		FILE_PATH = relativelyPath + "/testword.txt";
		logger.debug("FILE_PATH is: " + FILE_PATH);
	}

	/*
	 * return value: -1: failed; 0: file was not modified; 1: read successfully.
	 * make it as public instead of private, it is for the purpose of Unit Test.
	 */
	public int readTxtFile(String fileName) {

		BufferedReader reader = null;
		try {

			// if stop signal was set as true, then stop timer task;
			if (taskStopSignal) {
				if (myTask != null) {
					myTask.cancel();
					loopCounter = 0;
					logger.info("Task has been stopped.");
				} else {
					logger.info("Task is not running.");
				}
			}

			java.io.File file = new java.io.File(fileName);
			if (!file.exists()) {
				logger.error("File does not exist.");
				return -1;
			}

			if (file.length() > MAX_SIZE_OF_FILE) {
				logger.warn("File is too big to be loaded.");
				return -1;
			}

			if (!checkFileModified(file)) {
				logger.info("Current file has no update.");
				return 0;
			}

			String separator = ",";

			reader = new BufferedReader(new FileReader(fileName));
			String ringRecords = "";

			// clear existing elements
			wordlist.clear();
			// put the latest elements into array
			while ((ringRecords = reader.readLine()) != null) {
				if (!ringRecords.trim().equals("")) {
					String[] part = ringRecords.split(separator);
					for (int i = 0; i < part.length; i++) {
						wordlist.add(part[i].trim());
					}
				}
				
			}

			// close buffered reader
			if (reader != null) {
				reader.close();
				reader = null;
			}
			
			logger.debug(wordlist);

		} catch (Exception e) {
			logger.error(e);
			return -1;
		} finally {
		}
		return 1;
	}

	private boolean checkFileModified(java.io.File file) {
		if (file.length() == lastUpdateFileSize
				&& file.lastModified() == lastUpdateFileModified) {
			return false;
		}
		lastUpdateFileSize = file.length();
		lastUpdateFileModified = file.lastModified();
		return true;
	}

	class MyTask extends java.util.TimerTask {
		public void run() {

			loopCounter++;

			int result = readTxtFile(FILE_PATH);
			if (result == 0) {
				logger.info("File was not modified.");
				return;
			} else if (result != 1) {
				logger.error("Load file failed due to unknown reason.");
				return;
			} else {
				//result == 1, load data into dataBank
					dataBank.loadData(wordlist);
			}
			return;
			// System.out.println(WordContainer.getContainer().getWordList());
		}
	}
}
