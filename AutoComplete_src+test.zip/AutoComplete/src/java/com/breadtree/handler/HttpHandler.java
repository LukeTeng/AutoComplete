package com.breadtree.handler;

import java.util.ArrayList;

import com.breadtree.databank.DataBank;

public class HttpHandler implements Handler {

	DataBank dataBank;
	
	public void syncData() {
		// to be implemented
	}
	
	public ArrayList<String> matchData(String prefix) {
		ArrayList<String> retlist = new ArrayList<String>();
		
		//To be implemented
		
		return retlist;
	}

	@Override
	public DataBank getDataBank() {
		return dataBank;
	}
	
	@Override
	public void setDataBank(DataBank dataBank) {
		this.dataBank = dataBank;
	}
	
}
