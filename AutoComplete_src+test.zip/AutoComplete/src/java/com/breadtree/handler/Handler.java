package com.breadtree.handler;

import com.breadtree.databank.DataBank;

public interface Handler {

	/*
	 * this method is to trigger a timer task to read file frequently
	 */
	public void syncData();

	/*
	 * get the DataBank instance declared by its implementation
	 */
	public DataBank getDataBank();

	/*
	 * set the DataBank instance declared by its implementation
	 */
	public void setDataBank(DataBank dataBank);

}
